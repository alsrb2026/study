package org.techtown.recyclerview;

public class Person {
    String name;
    String mobile;
    String birth;

    public Person(String name, String mobile, String birth) {
        this.name = name;
        this.mobile = mobile;
        this.birth = birth;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobile() {
        return mobile;
    }

    public String getBirth() {
        return birth;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
}
